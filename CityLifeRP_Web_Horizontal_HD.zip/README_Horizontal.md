# City Life RP — Web Horizontal HD

Версия оптимизирована под горизонтальный экран iPhone/iPad.
- Landscape-first UI
- HD/glass HUD styling
- Touch-friendly controls
- PWA-ready
- Существующая игровая логика сохранена

На iPhone откройте сайт в Safari и поверните устройство горизонтально.
Для публикации используйте HTTPS-хостинг, затем Safari → Поделиться → На экран «Домой».
